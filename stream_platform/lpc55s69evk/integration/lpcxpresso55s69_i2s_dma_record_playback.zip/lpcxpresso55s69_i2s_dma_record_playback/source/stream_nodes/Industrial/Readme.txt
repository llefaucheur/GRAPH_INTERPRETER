----------------------------
Node categories and examples
----------------------------
Motion: 9-AXIS motion sensing, metadata extraction

