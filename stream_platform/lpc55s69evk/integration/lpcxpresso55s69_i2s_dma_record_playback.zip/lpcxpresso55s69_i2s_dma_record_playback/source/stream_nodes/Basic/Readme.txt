----------------------------
Node categories and examples
----------------------------
Router, Mixer, rate converter, interpolator, rescaler