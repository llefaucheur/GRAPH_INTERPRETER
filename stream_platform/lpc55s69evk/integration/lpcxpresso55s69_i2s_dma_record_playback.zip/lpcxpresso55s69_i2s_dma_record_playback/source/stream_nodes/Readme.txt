----------------------------
Node categories and examples
----------------------------
Audio : pre/post-processing, 3GPP/ITU/MPEG CODEC
Image : PNG/JPG CODEC, color conversion, resize/rotation
Motion: 9-AXIS motion sensing, metadata extraction
Sense : other sensors (temperature, position, electrical, chemical,..)
Speech: ASR, TTS, Biometrics, VAD
Video : MPEG CODEC, Detectors