----------------------------
Node categories and examples
----------------------------
detection audio and image patterns 
Models for sensor machine learning (temperature, position, electrical, chemical,..)
