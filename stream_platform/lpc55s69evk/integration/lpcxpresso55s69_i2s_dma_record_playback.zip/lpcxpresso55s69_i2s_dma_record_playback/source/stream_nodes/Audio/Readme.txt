----------------------------
Node category and examples
----------------------------
Audio  : pre/post-processing, 3GPP/ITU/MPEG CODEC
