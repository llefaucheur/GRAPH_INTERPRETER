----------------------------
Node categories and examples
----------------------------
Image : PNG/JPG CODEC, color conversion, resize/rotation
Video : MPEG CODEC 
