
If you want to reproduce the bug: 

The project is located at C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_make\Computer2


Rebuild started at 3:45 PM...
1>------ Rebuild All started: Project: Computer2, Configuration: Debug x64 ------
1>arm_stream_amplifier.c
1>arm_stream_amplifier_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\amplifier\arm_stream_amplifier_process.c(166,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_analysis.c
1>arm_stream_analysis_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\analysis\arm_stream_analysis_process.c(54,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_demodulator.c
1>arm_stream_demodulator_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\demodulator\arm_stream_demodulator_process.c(56,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_filter2D.c
1>arm_stream_filter.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\filter\arm_stream_filter.h(55,20): warning C4820: '<unnamed-tag>': '6' bytes padding added after data member 'postShift'
1>(compiling source file '../../../stream_nodes/arm/filter/arm_stream_filter.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\filter\arm_stream_filter.h(134,14): warning C4820: '<unnamed-tag>': '4' bytes padding added after data member 'iir_service'
1>(compiling source file '../../../stream_nodes/arm/filter/arm_stream_filter.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\filter\arm_stream_filter.c(257,37): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\filter\arm_stream_filter.c(259,38): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>arm_stream_format_converter.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter.h(38,10): warning C4464: relative include path contains '..'
1>(compiling source file '../../../stream_nodes/arm/format_converter/arm_stream_format_converter.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter.c(100,63): warning C4312: 'type cast': conversion from 'intPtr_t' to 'arm_stream_format_converter_instance *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter.c(132,22): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter.c(135,22): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter.c(96,33): warning C4189: 'stream_entry': local variable is initialized but not referenced
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter.c(98,22): warning C4189: 'preset': local variable is initialized but not referenced
1>arm_stream_format_converter_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter.h(38,10): warning C4464: relative include path contains '..'
1>(compiling source file '../../../stream_nodes/arm/format_converter/arm_stream_format_converter_process.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter_process.c(78,5): warning C4065: switch statement contains 'default' but no 'case' labels
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter_process.c(65,152): warning C4100: 'status': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter_process.c(65,136): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter_process.c(97,144): warning C4100: 'in_out': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter_process.c(97,119): warning C4100: 'out': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter_process.c(97,79): warning C4100: 'in': unreferenced formal parameter
1>arm_stream_mixer.c
1>arm_stream_mixer_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\mixer\arm_stream_mixer_process.c(171,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_modulator.c
1>arm_stream_modulator_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\modulator\arm_stream_modulator_process.c(58,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_qos.c
1>arm_stream_qos_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\qos\arm_stream_qos_process.c(56,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_rescaler.c
1>arm_stream_rescaler_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\rescaler\arm_stream_rescaler_process.c(57,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_router.c
1>arm_stream_router_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\router\arm_stream_router_process.c(65,1): warning C4206: nonstandard extension used: translation unit is empty
1>Generating Code...
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\format_converter\arm_stream_format_converter_process.c(79,1): warning C4702: unreachable code
1>Compiling...
1>arm_stream_script.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\script\arm_stream_script.c(36,5): warning C4668: 'CODE_ARM_STREAM_SCRIPT' is not defined as a preprocessor macro, replacing with '0' for '#if/#elif'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\script\arm_stream_script.c(178,89): warning C4100: 'status': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\script\arm_stream_script.c(178,69): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\script\arm_stream_script.c(178,53): warning C4100: 'instance': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\script\arm_stream_script.c(178,38): warning C4100: 'command': unreferenced formal parameter
1>arm_stream_script_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\arm\script\arm_stream_script_process.c(700,1): warning C4206: nonstandard extension used: translation unit is empty
1>arm_stream_split.c
1>bitbank_JPEGENC.c
1>TjpgDec.c
1>sigp_stream_compressor.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.h(30,10): warning C4464: relative include path contains '..'
1>(compiling source file '../../../stream_nodes/signal-processingFR/compressor/sigp_stream_compressor.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(104,58): warning C4312: 'type cast': conversion from 'intPtr_t' to 'sigp_stream_compressor_instance *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(105,30): warning C4312: 'type cast': conversion from 'intPtr_t' to 'uint32_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(113,69): warning C4311: 'type cast': pointer truncation from 'void *' to 'intPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(113,47): warning C4312: 'type cast': conversion from 'intPtr_t' to 'stream_al_services (__cdecl *)' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(135,38): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(138,38): warning C4312: 'type cast': conversion from 'intPtr_t' to 'uint8_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(100,33): warning C4189: 'stream_entry': local variable is initialized but not referenced
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor.c(102,22): warning C4189: 'preset': local variable is initialized but not referenced
1>sigp_stream_compressor_imadpcm.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor_imadpcm.c(138,20): warning C4242: '=': conversion from 'uint32_t' to 'int16_t', possible loss of data
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor_imadpcm.c(139,18): warning C4242: '=': conversion from 'uint32_t' to 'int16_t', possible loss of data
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\compressor\sigp_stream_compressor_imadpcm.c(195,44): warning C4244: '=': conversion from 'int' to 'uint8_t', possible loss of data
1>sigp_stream_decompressor.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.h(69,13): warning C4820: '<unnamed-tag>': '3' bytes padding added after data member 'decoder_state'
1>(compiling source file '../../../stream_nodes/signal-processingFR/decompressor/sigp_stream_decompressor.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.h(70,14): warning C4820: '<unnamed-tag>': '4' bytes padding added after data member 'memory_state'
1>(compiling source file '../../../stream_nodes/signal-processingFR/decompressor/sigp_stream_decompressor.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(112,60): warning C4312: 'type cast': conversion from 'intPtr_t' to 'sigp_stream_decompressor_instance *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(113,30): warning C4312: 'type cast': conversion from 'intPtr_t' to 'uint32_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(121,69): warning C4311: 'type cast': pointer truncation from 'void *' to 'intPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(121,47): warning C4312: 'type cast': conversion from 'intPtr_t' to 'stream_al_services (__cdecl *)' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(148,38): warning C4312: 'type cast': conversion from 'intPtr_t' to 'uint8_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(151,38): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(108,33): warning C4189: 'stream_entry': local variable is initialized but not referenced
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.c(110,22): warning C4189: 'preset': local variable is initialized but not referenced
1>sigp_stream_decompressor_imadpcm.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.h(69,13): warning C4820: '<unnamed-tag>': '3' bytes padding added after data member 'decoder_state'
1>(compiling source file '../../../stream_nodes/signal-processingFR/decompressor/sigp_stream_decompressor_imadpcm.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor.h(70,14): warning C4820: '<unnamed-tag>': '4' bytes padding added after data member 'memory_state'
1>(compiling source file '../../../stream_nodes/signal-processingFR/decompressor/sigp_stream_decompressor_imadpcm.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor_imadpcm.c(134,20): warning C4242: '=': conversion from 'int32_t' to 'int16_t', possible loss of data
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\decompressor\sigp_stream_decompressor_imadpcm.c(135,18): warning C4242: '=': conversion from 'int32_t' to 'int16_t', possible loss of data
1>sigp_stream_detector2D.c
1>sigp_stream_detector2D_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\detector2D\sigp_stream_detector2D_process.c(73,1): warning C4206: nonstandard extension used: translation unit is empty
1>sigp_stream_detector.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\detector\sigp_stream_detector.c(114,49): warning C4312: 'type cast': conversion from 'intPtr_t' to 'sigp_detector_instance *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\detector\sigp_stream_detector.c(115,34): warning C4312: 'type cast': conversion from 'intPtr_t' to 'sigp_backup_memory *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\detector\sigp_stream_detector.c(194,22): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\detector\sigp_stream_detector.c(197,22): warning C4312: 'type cast': conversion from 'intPtr_t' to 'int16_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\detector\sigp_stream_detector.c(110,33): warning C4189: 'stream_entry': local variable is initialized but not referenced
1>sigp_stream_detector_process.c
1>sigp_stream_resampler.c
1>sigp_stream_resampler_process.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_nodes\signal-processingFR\resampler\sigp_stream_resampler_process.c(56,1): warning C4206: nonstandard extension used: translation unit is empty
1>platform_computer.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_src\stream_types.h(97,13): warning C4820: '<unnamed-tag>': '3' bytes padding added after data member 'error_log'
1>(compiling source file '../../../stream_platform/computer/platform_computer.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer.c(279,20): warning C4311: 'type cast': pointer truncation from 'uint8_t *' to 'sintPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer.c(279,40): warning C4311: 'type cast': pointer truncation from 'uint8_t *' to 'sintPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer.c(314,14): warning C4311: 'type cast': pointer truncation from 'uint8_t *' to 'intPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer.c(320,12): warning C4312: 'type cast': conversion from 'intPtr_t' to 'void *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer.c(604,30): warning C4311: 'type cast': pointer truncation from 'uint32_t *' to 'intPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer.c(629,13): warning C4312: 'type cast': conversion from 'intPtr_t' to 'uint8_t *' of greater size
1>platform_computer_io_services.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_src\stream_types.h(97,13): warning C4820: '<unnamed-tag>': '3' bytes padding added after data member 'error_log'
1>(compiling source file '../../../stream_platform/computer/platform_computer_io_services.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(64,77): warning C4100: 's': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(64,64): warning C4100: 'd': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(64,55): warning C4100: 'i': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(64,36): warning C4100: 'c': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(102,55): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(144,37): warning C4312: 'type cast': conversion from 'intPtr_t' to 'uint32_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(151,30): warning C4311: 'type cast': pointer truncation from 'int16_t [16]' to 'intPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(157,15): warning C4267: '=': conversion from 'size_t' to 'int32_t', possible loss of data
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(194,37): warning C4312: 'type cast': conversion from 'intPtr_t' to 'uint32_t *' of greater size
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(202,15): warning C4267: '=': conversion from 'size_t' to 'int32_t', possible loss of data
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(221,57): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(242,56): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(263,53): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(284,56): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(325,30): warning C4311: 'type cast': pointer truncation from 'uint32_t [8]' to 'intPtr_t'
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(345,56): warning C4100: 'data': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_io_services.c(383,30): warning C4311: 'type cast': pointer truncation from 'int16_t [16]' to 'intPtr_t'
1>platform_computer_services.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_src\stream_types.h(97,13): warning C4820: '<unnamed-tag>': '3' bytes padding added after data member 'error_log'
1>(compiling source file '../../../stream_platform/computer/platform_computer_services.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\stream_libraries\CMSIS-DSP\Include\dsp\support_functions.h(346,18): warning C4820: '<unnamed-tag>': '4' bytes padding added after data member 'dir'
1>(compiling source file '../../../stream_platform/computer/platform_computer_services.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\stream_libraries\CMSIS-DSP\Include\dsp\Computer_filtering_functions.h(61,18): warning C4820: '<unnamed-tag>': '6' bytes padding added after data member 'postShift'
1>(compiling source file '../../../stream_platform/computer/platform_computer_services.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\stream_libraries\CMSIS-DSP\Include\dsp\Computer_filtering_functions.h(70,20): warning C4820: '<unnamed-tag>': '4' bytes padding added after data member 'numStages'
1>(compiling source file '../../../stream_platform/computer/platform_computer_services.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(210,113): warning C4100: 'n': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(210,98): warning C4100: 'ptr3': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(210,83): warning C4100: 'ptr2': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(210,68): warning C4100: 'ptr1': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(274,117): warning C4100: 'n': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(274,102): warning C4100: 'ptr3': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(274,87): warning C4100: 'ptr2': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(274,72): warning C4100: 'ptr1': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(299,106): warning C4100: 'n': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(299,91): warning C4100: 'ptr3': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(299,76): warning C4100: 'ptr2': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(299,61): warning C4100: 'ptr1': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(299,43): warning C4100: 'command': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(335,104): warning C4100: 'n': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(335,89): warning C4100: 'ptr3': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(335,74): warning C4100: 'ptr2': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(335,59): warning C4100: 'ptr1': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(335,41): warning C4100: 'command': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(368,108): warning C4100: 'n': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(368,93): warning C4100: 'ptr3': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(368,78): warning C4100: 'ptr2': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(368,63): warning C4100: 'ptr1': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(368,45): warning C4100: 'command': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(388,108): warning C4100: 'n': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(388,93): warning C4100: 'ptr3': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(388,78): warning C4100: 'ptr2': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(388,63): warning C4100: 'ptr1': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(388,45): warning C4100: 'command': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(409,110): warning C4100: 'n': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(409,95): warning C4100: 'ptr3': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(409,80): warning C4100: 'ptr2': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(409,65): warning C4100: 'ptr1': unreferenced formal parameter
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_platform\computer\platform_computer_services.c(409,47): warning C4100: 'command': unreferenced formal parameter
1>stream_graph_interpreter.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_src\stream_types.h(97,13): warning C4820: '<unnamed-tag>': '3' bytes padding added after data member 'error_log'
1>(compiling source file '../../../stream_src/stream_graph_interpreter.c')
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_src\stream_graph_interpreter.c(63,95): warning C4100: 'size': unreferenced formal parameter
1>stream_io.c
1>C:\Work\GITHUB_LLF\GRAPH_INTERPRETER\stream_src\stream_types.h(97,13): warning C4820: '<unnamed-tag>': '3' bytes padding added after data member 'error_log'
1>(compiling source file '../../../stream_src/stream_io.c')
1>Generating Code...
1>  CL!RaiseException()+0x6c
1>  CL!RaiseException()+0x6c
1>  CL!InvokeCompilerPassW()+0xb2713
1>  CL!InvokeCompilerPassW()+0x12dffb
1>INTERNAL COMPILER ERROR in 'C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Tools\MSVC\14.43.34808\bin\HostX64\x64\CL.exe'
1>    Please choose the Technical Support command on the Visual C++
1>    Help menu, or open the Technical Support help file for more information
1>C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Microsoft\VC\v170\Microsoft.CppCommon.targets(781,5): error MSB6006: "CL.exe" exited with code -529706956.
1>Done building project "Computer2.vcxproj" -- FAILED.
========== Rebuild All: 0 succeeded, 1 failed, 0 skipped ==========
========== Rebuild completed at 3:45 PM and took 01.462 seconds ==========


