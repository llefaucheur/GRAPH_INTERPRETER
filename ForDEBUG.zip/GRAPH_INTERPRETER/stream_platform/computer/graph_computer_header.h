//--------------------------------------
//  DATE Tue Apr  8 10:31:00 2025
//  AUTOMATICALLY GENERATED CODES
//  DO NOT MODIFY !
//--------------------------------------

#define arm_stream_format_converter_0       0xF // node position in the graph
#define arm_stream_format_converter_0_arc_0 0x10 // node arc
#define arm_stream_format_converter_0_arc_1 0x10 // node arc
                        // COPY_CONF_GR0 OFF 0 BASE 0x0000 PT 0x0000 MAXW 0x0000 SIZE_bytes 0044 

#define arc_0      0x20 // arc descriptor position in the graph
                        // _0_buff OFF 0 BASE 0x0044 PT 0x0044 MAXW 0x0000 SIZE_bytes 0000 
#define arc_buf_0  0x44 // arc buffer address
#define arc_1      0x26 // arc descriptor position in the graph
                        // _1_buff OFF 0 BASE 0x0044 PT 0x0044 MAXW 0x0000 SIZE_bytes 0000 
#define arc_buf_1  0x44 // arc buffer address


                        //  OFF 0 BASE 0x0044 PT 0x0044 MAXW 0x0000 SIZE_bytes 0064 
#define arm_stream_format_converter 0x44 // node static memory address
